# Bridge
# This file and those that follow are open source.
# Program written by: Laure-Anne Barel, Ghali Boucetta, Hugo Demaret.
# This project was made while studying comp-science at Descartes University, Paris, France.
# This game is a computer-based Bridge.
